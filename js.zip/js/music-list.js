let allMusic = [

    {
        name:"roozhaye bi gharar",
        artist:"Ghorbani",
        img:"music-1",
        src:"music-1"
    },
    {
        name:"to mara jan va jahani (live)",
        artist:"Ghorbani",
        img:"music-2",
        src:"music-2"
    },
    {
        name:"scent of Hair",
        artist:"Ghorbani",
        src:"music-3",
        img:"music-3",
    },
    {
        name:"hamgonah",
        artist:"Ghorbani",
        img:"music-4",
        src:"music-4"
    },
    {
        name:"mara bebakhsh",
        artist:"Ghorbani",
        img:"music-5",
        src:"music-5"
    },
    {
        name:"Dar zolfe to avizam",
        artist:"Ghorbani",
        img:"music-6",
        src:"music-6"
    },
    {
        name:"Ziba",
        artist:"arman garshasbi",
        img:"music-7",
        src:"music-7"
    },
    {
        name:"yek nafas arezoye to",
        artist:"shajarian",
        img:"music-8",
        src:"music-8"
    },
    {
        name:"parishani",
        artist:"Ghorbani",
        img:"music-9",
        src:"music-9"
    },
    {
        name:"maste eshgh",
        artist:"Ghorbani",
        img:"music-10",
        src:"music-10"
    },
    {
        name:"Aseman ham zamin",
        artist:"Chartar",
        img:"music-11",
        src:"music-11"
    },
    {
        name:"Eshgh Asan nadarad",
        artist:"Ghorbani",
        img:"music-12",
        src:"music-12"
    },
]